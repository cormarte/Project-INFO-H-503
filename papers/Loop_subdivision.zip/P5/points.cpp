#include "points.h"
#include <algorithm>

Point3D32f Point3D32f::max ( const Point3D32f& rhs ) const
{
	return Point3D32f ( std::max ( x, rhs.x), std::max (y, rhs.y ), std::max (z, rhs.z ) );
}

Point3D32f Point3D32f::min ( const Point3D32f& rhs ) const
{
	return Point3D32f ( std::min ( x, rhs.x), std::min (y, rhs.y ), std::min (z, rhs.z ) );
}

float Point3D32f::min () const
{
	return std::min ( fabs(x), std::min (fabs(y),fabs(z)) );
}

float Point3D32f::max () const
{
	return std::max ( fabs(x), std::max (fabs(y),fabs(z)) );
}

Point3D32f Point3D32f::cross ( const Point3D32f& rhs) const
{
	return Point3D32f ( y * rhs.z - z * rhs.y, z * rhs.x - x * rhs.z, x * rhs.y - y * rhs.x );
}

bool Point3D32f::operator== (const Point3D32f& rhs) const 
{
	const float eps = 1e-6f * std::max (std::max ( x, y) , z );

	if ( fabs ( x - rhs.x) < eps && fabs ( y - rhs.y ) < eps && fabs ( z - rhs.z ) < eps )
		return true;
	else
		return false;
}


std::ostream& operator<< ( std::ostream& os, const Point3D32f& p )
{
	os << "( " << p.x << " , " << p.y << " , " << p.z << " ) ";
	return os;
}

Point3D32f Matrix3D32f::mult (const Point3D32f& p) const
{
	Point3D32f res;
	for ( int i =0; i < 3; ++i ) {
		for (int j =0; j < 3; ++j )
		*(((float*)&res)+i) += at(i,j) * *(((float*)&p)+j);
	}

	return res;
}

Matrix3D32f Matrix3D32f::transpose () const
{
	Matrix3D32f res;
	for ( int i =0; i < 3; ++i ) {
		for (int j =0; j < 3; ++j )
			res.at(i,j) = at(j,i);
	}
	return res;
}
Matrix3D32f Point3D32f::normRotX ()
{
	Point3D32f a(*this);
	a.normalize();

	Point3D32f n(a);
	float m = a.min();
	if ( fabs(a.x) == m )
		n.x = 1.0;
	else if (fabs(a.y) == m)
		n.y = 1.0;
	else
		n.z = 1.0;

	Point3D32f b = a.cross(n);
	b.normalize();

	Point3D32f c = a.cross(b);

	Matrix3D32f res;
	memcpy ( &res.at(0,0), &b, 3*sizeof(float));
	memcpy ( &res.at(0,0)+3, &c, 3*sizeof(float));
	memcpy ( &res.at(0,0)+6, &a, 3*sizeof(float));

	return res;
	
}
