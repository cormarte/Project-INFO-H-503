In command prompt go to P5 directory
Example usage: Release\P5.exe -file models\torus.ply -subdivide 4

See models directory for more models.

All models courtesy of Greg Turk ( turk@cc.gatech.edu )