
#include "ObjFile.h"
#include <windows.h>
#include "gl.h"
#include "glut.h"
#include "glu.h"
#include <string>
#include <iostream>

ObjFile* objFile =0;
/* light position */
GLfloat  lightPos[] = { -1.0, 1.0, 1.0, 0.0 };

/* light contribution */
GLfloat  ambientLight[] = { 0.4, 0.4, 0.4, 1.0 };
GLfloat  diffuseLight[] = { 0.6, 0.6, 0.6, 1.0 };
GLfloat  specularLight[] = { 0.5, 0.5, 1.0, 1.0};

LONGLONG freq_;
LONGLONG oldTime_;
LONGLONG curTime_;
	
float angle =0;
int g_subLevel =0;
GLuint flatModel;

void renderFrame ()
{
	QueryPerformanceCounter ((LARGE_INTEGER*) &curTime_);
	double msecs = (double) (( curTime_ - oldTime_) * 1e6 / freq_ ) / 1e3; 
	oldTime_ = curTime_;

	angle += 360.0 / 5000.0 * msecs;
	while ( angle > 360.0 ) angle -= 360.0; 
	while ( angle < 0.0 ) angle += 360.0;

    glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);
	glLoadIdentity ();
	gluLookAt ( .0, .0, 6.0, .0, .0, .0, .0, 1.0, .0 );
	glLightfv(GL_LIGHT0,GL_POSITION,lightPos);
	
	glPushMatrix ();
	glTranslatef ( -2.0, 0, 0 );
	glRotatef ( angle, .0, 1.0, .0 );
	glRotatef ( 30, 1, 0 , 0);
	glShadeModel (GL_FLAT);
	glCallList (flatModel);
	glPopMatrix ();

	glTranslatef (2.0, 0,0 );
	glRotatef (angle, .0, 1.0, .0 );
	glRotatef ( 30, 1,0,0);
	glShadeModel (GL_SMOOTH);

	glCallList ( objFile->getModel () );
	glutSwapBuffers();
}

void display(void)
{
  renderFrame ();
}

/******************************************************************************
Initialize the OpenGL graphics context.
******************************************************************************/

void init(void) {

  /* select clearing color */ 

  glClearColor (0.0, 0.0, 0.0, 0.0);
  glShadeModel (GL_SMOOTH);

  /* initialize viewing values */

  glMatrixMode(GL_PROJECTION);
  glLoadIdentity();
  gluPerspective ( 60.0, 640.0 / 480.0, 1e-3, 100 );
  glMatrixMode (GL_MODELVIEW);
  
  objFile->findAdjTriangles ();
  if ( !g_subLevel)
      objFile->computeNormals ();

  flatModel = objFile->createModel (true);

  for ( int i =0; i < g_subLevel; ++i )
	  objFile->subdivide ();

  
  objFile->createModel ();
  glEnable(GL_DEPTH_TEST);   
  glEnable ( GL_CULL_FACE);
  glEnable (GL_LIGHTING);

  /* create intensity contributions of the light */
  glLightfv(GL_LIGHT0, GL_AMBIENT, ambientLight);
  glLightfv(GL_LIGHT0, GL_DIFFUSE, diffuseLight);
//  glLightfv(GL_LIGHT0, GL_SPECULAR, specularLight);

  
  /* turn on light zero */
  glEnable(GL_LIGHT0);
  //	glEnable(GL_COLOR_MATERIAL);
//	glColorMaterial(GL_FRONT_AND_BACK, GL_AMBIENT_AND_DIFFUSE);

}

void printUsage ()
{
	std::cout << "Usage of P5:\n";
	std::cout << "P5.exe -file FILENAME -subdivide LEVEL\n";
}

int main(int argc, char** argv) {

	std::string fileName;

	if ( argc > 2) {

		if ( std::string(argv[1]) == "-file" ) 
			fileName = argv[2];
		else {
			printUsage ();
			return 1;
		}

		if ( argc > 4 )
		{
			if ( std::string ( argv[3] ) == "-subdivide" )
				g_subLevel = atoi ( argv[4] );
			else {
				printUsage ();
				return 1;
			}
		}
	}
	else
	{
		printUsage ();
		return 1;
	}

  std::cout << "Using file " << fileName << " with subdivision level " << g_subLevel << "\n";
  
  objFile = new ObjFile ( fileName );

  glutInit(&argc, argv);
  glutInitDisplayMode (GLUT_DOUBLE | GLUT_RGB | GLUT_DEPTH);
  glutInitWindowSize (640, 480); 
  glutInitWindowPosition (100, 100);
  glutCreateWindow (argv[0]);
  init ();

  glutDisplayFunc(display); 
  glutIdleFunc (renderFrame);

  QueryPerformanceFrequency ((LARGE_INTEGER*)&freq_);
  QueryPerformanceCounter ((LARGE_INTEGER*) &oldTime_);

  glutMainLoop(); 

  delete objFile;

  return 0;   
}

