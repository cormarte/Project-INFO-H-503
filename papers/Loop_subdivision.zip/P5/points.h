
#ifndef POINTS_H
#define POINTS_H

#define _USE_MATH_DEFINES
#include <cmath>
#include <iostream>

class Point3D32f;

class Matrix3D32f
{
public:
	Matrix3D32f() { setZero(); }
	Matrix3D32f setZero() { memset (d_, 0, 9*sizeof(float) ); return *this; }
	float& at(int i, int j) { return d_[3*i+j]; }
	float at (int i, int j ) const {return d_[3*i+j];}
	Point3D32f mult (const Point3D32f&) const;
	Matrix3D32f transpose () const;
protected:
	float d_[9];
};

class Point3D32f
{
public:
	Point3D32f (float fx=0.0, float fy=0.0, float fz=0.0 ) : x(fx), y(fy), z(fz) {}
	void set (float fx=0.0, float fy=0.0, float fz=0.0 ) {  x = fx, y = fy, z = fz; }
	Point3D32f min ( const Point3D32f& ) const; // min for each component
	Point3D32f max ( const Point3D32f& ) const; // dito
	float min () const;
	float max () const;
	float norm () const { return std::sqrt (x*x+y*y+z*z); }
	Point3D32f& normalize() { return scale(1.0f/norm()); }
	Point3D32f& scale (float s) { x*=s; y*=s; z*=s; return *this; }
	Point3D32f cross ( const Point3D32f& rhs) const;
	Matrix3D32f normRotX ();


	Point3D32f operator+ ( const Point3D32f& rhs) const { return Point3D32f ( x + rhs.x, y + rhs.y, z +rhs.z ); }
	Point3D32f operator- ( const Point3D32f& rhs) const { return Point3D32f ( x - rhs.x, y - rhs.y, z -rhs.z ); }
	Point3D32f operator* ( float f ) const { return Point3D32f ( x * f, y * f, z * f); }
	bool operator== (const Point3D32f& rhs) const;
	float x,y,z;

};

std::ostream& operator<< ( std::ostream& os, const Point3D32f& p );

class Point2D32f
{
public:
	Point2D32f (float fx=0.0, float fy=0.0 ) : x(fx), y(fy) {}
	void set (float fx=0.0, float fy=0.0 ) {  x = fx, y = fy; }
	Point2D32f& add (const Point2D32f& rhs) { x += rhs.x; y += rhs.y; return *this; }
	Point2D32f& scale (float s) { x*=s; y*=s; return *this; }
	float norm () const { return std::sqrt (x*x+y*y); }
	Point2D32f& normalize() { return scale(1.0f/norm()); }

	float x,y;

};

#endif